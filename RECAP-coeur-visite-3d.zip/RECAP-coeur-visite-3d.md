# 📋 Cœur Visite 3D — État du projet (à jour au 5 juillet 2026)

## 🔗 Adresses
- **Site (visite)** : https://jeanmichelnizet.github.io/icoeurvisit/
- **Éditeur (back-office)** : https://jeanmichelnizet.github.io/icoeurvisit/admin.html
- **Manuel** : https://jeanmichelnizet.github.io/icoeurvisit/manuel.html
- **Dépôt du code (GitHub)** : `jeanmichelnizet/icoeurvisit` (public)

## 🔑 Accès
- **Mot de passe du site** (visiteurs / éditeur) : `Coeur-XllTfOQ`
- **Éditeur** : bouton « Se connecter à GitHub » → coller un **jeton GitHub** (Personal Access Token « classic », permission **repo**).
  - Le jeton est stocké dans le navigateur (à recoller une fois par machine/navigateur).
  - ⚠️ Le jeton actuel est dans le fichier `.env` sur le Mac de bureau. Si tu ne l'as pas sous la main sur l'autre machine, tu peux en **générer un nouveau** : github.com/settings/tokens → « Generate new token (classic) » → cocher **repo**.

## ⚙️ Comment ça marche
- Tu modifies **tout le contenu** depuis l'éditeur, dans **n'importe quel navigateur** (aucun logiciel à installer).
- « Enregistrer » → le site se **met à jour en ligne tout seul** (~30 s à 1 min). Bandeau **orange → vert « Site à jour ✓ »** pour confirmer.
- Pour **éditer le contenu**, un navigateur + le jeton suffisent. Pour **modifier le code**, il faut cloner le dépôt GitHub.

## ✅ Ce qui est fait
- Visite 3D du bateau, **8 points commentés**, **bilingue FR/EN**, **audio guidé** (FR).
- **PWA** installable / résiliente hors-ligne (pour le QR sur le ponton).
- **Éditeur en ligne** : textes FR/EN, **photos multiples par rubrique** (galerie + carrousel), vidéos, panoramas 360°, **vues 3D intérieures** (embeds superspl.at), **vidéos 360° YouTube**.
- Vignettes **vert = en ligne / rouge = à enregistrer**, barre de progression, aperçu avant publication.
- **Protection par mot de passe** + pages en noindex.

## 🩹 Corrections récentes (juillet 2026)
- Galerie multi-photos : **noms de fichiers uniques** (fin des collisions de photos iPhone).
- Panneau d'un point qui **se referme** au changement de vue.
- **Gros correctif de cache** : GitHub servait les fichiers 10 min en cache → le service worker force désormais du frais (`no-store`) + le site se **recharge tout seul** à chaque nouvelle version. ⚠️ **Safari** reste le plus têtu : si un doute, recharger avec **alt+shift+r** (ou fermer/rouvrir l'onglet sur mobile).

## 🚧 En cours / à faire

### 1. Vidéos 360° ← le point où on s'est arrêté
- Constat vérifié : **YouTube ne permet PAS la navigation 360° en embed** sur un site externe (la vidéo s'affiche à plat). Ce n'est pas corrigeable de notre côté.
- **Solution retenue** : héberger la 360° sur **Vimeo** (recommandé) ou **VeeR VR** — leurs lecteurs, eux, autorisent la navigation 360° en embed.
- **Étape bloquante** : il faut le **fichier vidéo d'origine** (MP4 de la caméra 360). La vidéo test est sur la chaîne YouTube **« Ulysse Nizet »** → Ulysse peut fournir le fichier, ou le télécharger depuis **YouTube Studio**.
- **Ensuite** : uploader sur Vimeo → coller le lien d'embed dans l'éditeur → je le branche sur le lecteur plein cadre (comme les vues superspl.at). Navigation 360° garantie partout.

### 2. Domaine de production `visite.initiatives-coeur.fr`
- Domaine chez **OVH**, mais DNS géré par l'agence **Numerigraphe** (`dns1/dns2.numerigraphe.com`).
- **Action à faire** : demander à Numerigraphe d'ajouter un enregistrement DNS :
  - Type **CNAME**, nom **`visite`**, cible **`jeanmichelnizet.github.io.`**, TTL défaut.
- Une fois le DNS en place → me le dire → je bascule le côté GitHub (adresse + HTTPS), sans coupure.

### 3. Audio anglais
- Les descriptions audio **FR** sont en place ; les **EN** restent à générer/fournir.

---

## ▶️ Pour reprendre sur une autre machine
1. **Éditer le contenu** (photos, textes, vidéos) : ouvrir l'éditeur dans le navigateur, se connecter avec le jeton GitHub, modifier, Enregistrer. Rien d'autre à installer.
2. **Reprendre le développement du code** : cloner `jeanmichelnizet/icoeurvisit`. Les secrets (`.env`) ne sont QUE sur le Mac de bureau — les recopier si besoin.
3. **Prochaine action concrète** : récupérer auprès d'Ulysse le fichier MP4 360° d'origine pour la solution Vimeo/VeeR.
